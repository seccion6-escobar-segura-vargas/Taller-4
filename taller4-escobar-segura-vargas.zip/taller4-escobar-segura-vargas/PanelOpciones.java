package uniandes.dpoo.taller4.interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;


public class PanelOpciones extends JPanel implements ActionListener{
    
    private JButton nuevoBtn; 
    private JButton restartBtn; 
    private JButton top10Btn; 
    private JButton cambiarJugadorBtn; 

    private VentanaLightsOut padre; 

    private static final String NUEVO = "Nuevo";
    private static final String REINICIAR = "Reiniciar";
    private static final String TOP10 = "Top 10"; 
    private static final String CAMBIAR_JUGADOR = "Cambiar Jugador";

    public PanelOpciones(VentanaLightsOut padre) {
        
        this.padre = padre; 

        nuevoBtn = new JButton("NUEVO");
        restartBtn = new JButton("REINICIAR");
        top10Btn = new JButton("TOP-10"); 
        cambiarJugadorBtn = new JButton("CAMBIAR JUGADOR");

        nuevoBtn.addActionListener(this);
        restartBtn.addActionListener(this);
        top10Btn.addActionListener(this);
        cambiarJugadorBtn.addActionListener(this);

        nuevoBtn.setActionCommand(NUEVO);
        restartBtn.setActionCommand(REINICIAR);
        top10Btn.setActionCommand(TOP10);
        cambiarJugadorBtn.setActionCommand(CAMBIAR_JUGADOR);


        setLayout(new GridLayout(0,1));

        add(nuevoBtn); 
        add(restartBtn);
        add(top10Btn);
        add(cambiarJugadorBtn);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
    	
    	String command = e.getActionCommand();
    	
    	if(command.equals(NUEVO))
    		padre.nuevo();
    	else if(command.equals(REINICIAR))
    		padre.reiniciar();
    	else if (command.equals(TOP10))
    		padre.openTop10(); 
    	else if (command.equals(CAMBIAR_JUGADOR)){
        	padre.setJugador();
        }
    	
        
        
    }
    
}
