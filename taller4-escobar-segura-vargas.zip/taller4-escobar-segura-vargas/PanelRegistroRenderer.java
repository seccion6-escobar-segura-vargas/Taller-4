package uniandes.dpoo.taller4.interfaz;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;

public class PanelRegistroRenderer extends JPanel implements ListCellRenderer<PanelRegistroTop10> {
	
	public PanelRegistroRenderer() {
        setOpaque(true);
    }
	
	@Override
    public Component getListCellRendererComponent(JList<? extends PanelRegistroTop10> list, PanelRegistroTop10 registro, int index,
            boolean isSelected, boolean cellHasFocus) {
		
		
        
        //setText(pos.getText() + "      " + nombre.getText()  + "      " + puntos.getText()); 

        JLabel[] lbls = new JLabel[3];
        int i = 0; 
        for(Component c: registro.getComponents()) {
            lbls[i] = (JLabel) c; 
            i++; 
        }
        
        if(index < 3) { 
            for(JLabel lbl: lbls) 
                lbl.setForeground(Color.GREEN);
        }

        if(index == 3) {
            for(JLabel lbl: lbls) 
                lbl.setForeground(Color.BLUE);
        }
 
        if (isSelected) {
            registro.setBackground(list.getSelectionBackground());
            registro.setForeground(list.getSelectionForeground());
        } else {
            registro.setBackground(list.getBackground());
            registro.setForeground(list.getForeground());
        }
 
        return registro;
    }
}

