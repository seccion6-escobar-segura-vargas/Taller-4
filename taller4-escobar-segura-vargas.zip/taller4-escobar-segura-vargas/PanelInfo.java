package uniandes.dpoo.taller4.interfaz;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.FlowLayout;

public class PanelInfo extends JPanel {

    private JPanel panelJugadas;
    private JPanel panelJugador;

    private JLabel jugadas;
    private JLabel numJugadas;
    private JLabel jugador;
    private JLabel nomJugador;

    private int vecesJugadas;

    public PanelInfo(VentanaLightsOut padre, String nombre) {
        vecesJugadas = 0;

        this.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));

        panelJugadas = new JPanel();
        panelJugadas.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));

        panelJugador = new JPanel();
        panelJugador.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 5));

        jugadas = new JLabel();
        jugadas.setText("Jugadas:");
        numJugadas = new JLabel();
        numJugadas.setText("0");
        jugador = new JLabel();
        jugador.setText("Jugador:");
        nomJugador = new JLabel();
        nomJugador.setText(nombre);

        panelJugadas.add(jugadas);
        panelJugadas.add(numJugadas);

        panelJugador.add(jugador);
        panelJugador.add(nomJugador);

        this.add(panelJugadas);
        this.add(panelJugador);
    }


    public void actualizarJugadas(int jugadas) {
        numJugadas.setText(Integer.toString(jugadas));
    }


    public void actualizarNombre(String name) {
        nomJugador.setText(name);
    }
}
