package uniandes.dpoo.taller4.interfaz;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

import uniandes.dpoo.taller4.modelo.RegistroTop10;

public class PanelRegistroTop10 extends JPanel {
	
	private JLabel posicion;
	private JLabel nombre;
	private JLabel puntaje; 
	 
	public PanelRegistroTop10(RegistroTop10 registro, int pos){
		
		setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
    	
	

		posicion = new JLabel();
        nombre = new JLabel();
        puntaje = new JLabel();

        posicion.setText(Integer.toString(pos) + ":");
        nombre.setText(registro.darNombre());
        puntaje.setText(Integer.toString(registro.darPuntos()));

		Font font = new Font("SansSerif", Font.BOLD, 24);

		posicion.setFont(font);
		nombre.setFont(font); 
		puntaje.setFont(font); 

        add(posicion);
        add(nombre);
        add(puntaje);
		
        
        double width = posicion.getWidth() + nombre.getWidth() + puntaje.getWidth();

	}
	
	public JLabel getNameLabel() {
		return nombre;
	}
	
	public JLabel getPosLabel() {
		return posicion;
	}
	public JLabel getPuntajeLabel() {
		return puntaje;
	}
	
	

}
