package uniandes.dpoo.taller4.interfaz;

import uniandes.dpoo.taller4.modelo.RegistroTop10;

import javax.swing.DefaultListModel;
import javax.swing.JDialog;

import java.util.Collection;
import java.util.PriorityQueue;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class VentanaTop10 extends JDialog {

    private int pos;
    private JPanel sPanel;
    private JLabel sPosicion;
    private JLabel sNombre;
    private JLabel sPuntaje;
    
    private JPanel listPanel; 

    public VentanaTop10(Collection<RegistroTop10> registros) {
        
    	pos = 1;

        sPanel = new JPanel();
        listPanel = new JPanel();
        
        sPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10 ));

        sPosicion = new JLabel("#");
        sNombre = new JLabel("Nombre");
        sPuntaje = new JLabel("Puntos");

        Font font = new Font("SansSerif", Font.BOLD, 24);

        sPosicion.setFont(font);
        sNombre.setFont(font);
        sPuntaje.setFont(font);

        sPanel.add(sPosicion);
        sPanel.add(sNombre);
        sPanel.add(sPuntaje);
        
        
        DefaultListModel <PanelRegistroTop10> top10Model = new DefaultListModel<PanelRegistroTop10>();
        
        for (RegistroTop10 registro : registros) {
            
        	PanelRegistroTop10 panel = new PanelRegistroTop10(registro, pos); 
        	top10Model.addElement(panel);
        	++pos;
        }
        
        JList <PanelRegistroTop10> top10List = new JList<PanelRegistroTop10>(top10Model);
        
        top10List.setCellRenderer(new PanelRegistroRenderer());

        listPanel.add(new JScrollPane(top10List));
        
        
        pack();
        
        add(sPanel, BorderLayout.NORTH);
        add(listPanel, BorderLayout.CENTER);
        
        setResizable(false);
        
    }
}