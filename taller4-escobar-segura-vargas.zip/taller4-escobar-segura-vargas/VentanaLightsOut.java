package uniandes.dpoo.taller4.interfaz;

import java.awt.BorderLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.formdev.flatlaf.FlatDarkLaf;

import uniandes.dpoo.taller4.modelo.RegistroTop10;
import uniandes.dpoo.taller4.modelo.Tablero;
import uniandes.dpoo.taller4.modelo.Top10;

public class VentanaLightsOut extends JFrame {
	
	private Tablero modelo; 
	
	private Top10 top10; 
	
	private PanelConfiguracion panelConfiguracion; 
	private PanelTablero panelTablero; 
	private PanelOpciones panelOpciones; 
	private PanelInfo panelInfo; 

	private int dificultad;

	private String nombreJugador; 

	private int tam;

	private static final File FILE_TOP10 = new File("./data/top10.csv");

	

//	public static int TAM_LUZ = 50;
	

	public VentanaLightsOut () {


		panelConfiguracion = new PanelConfiguracion(this);
		
		modelo = new Tablero(tam);
		panelTablero = new PanelTablero(this, tam);
		
		nombreJugador = JOptionPane.showInputDialog(null, "Ingresar el nombre del jugador");
		
		panelInfo = new PanelInfo(this, nombreJugador); 
		
		nuevo();

		top10 = new Top10(); 
		top10.cargarRecords(FILE_TOP10);
		
		
		System.out.println("Antes");
		darTableroModelo();
		
		System.out.println("Despues");
		darTableroModelo();

		//setJugador();


		panelOpciones = new PanelOpciones(this);

		add(panelTablero, BorderLayout.CENTER);
		add(panelConfiguracion, BorderLayout.NORTH);
		add(panelInfo, BorderLayout.SOUTH);
		add(panelOpciones, BorderLayout.EAST);
		
		
		pack(); 
		setTitle("Lights Out");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null); // Centrar la ventana en la pantalla
		setResizable(false);
		setVisible(true);
		
		
	}
	
	public void jugar(int corx, int cory) throws FileNotFoundException, IOException {
		modelo.jugar(corx,cory);
		repaint();
		int jugadas = modelo.darJugadas();
		panelInfo.actualizarJugadas(jugadas);
		boolean iluminado = modelo.tableroIluminado();
		if(iluminado) 
		{
			int puntaje = modelo.calcularPuntaje();
			if(top10.esTop10(puntaje)) {
				top10.agregarRegistro(nombreJugador, puntaje);
				top10.salvarRecords(FILE_TOP10);
			}

			JOptionPane.showMessageDialog(this, "¡Ganaste en " + jugadas + " jugadas! \n Puntaje Final" + puntaje, "Fin del juego",
					JOptionPane.INFORMATION_MESSAGE);
			int reiniciar = JOptionPane.showConfirmDialog(this, "¿Quieres iniciar un nuevo juego?", "Reiniciar", JOptionPane.YES_NO_OPTION);

			if (reiniciar == JOptionPane.YES_OPTION)
			{
				reiniciar();
			}

			
		}
	}
	
	public void nuevo () {
		
		System.out.println("nuevo!");
		modelo = new Tablero(tam);
		modelo.desordenar(dificultad);
		panelInfo.actualizarJugadas(0);
		panelTablero.actualizarTamano(tam);
		panelTablero.repaint();
		add(panelTablero);
	}
	
	public void reiniciar () {
		System.out.println("reiniciar!");
		modelo.reiniciar();
		panelTablero.reiniciarCantidades();
		panelInfo.actualizarJugadas(0);
		repaint();
	}
	
	
	public void setTamanio(int tam) {
		this.tam = tam; 
		System.out.println("Tamanio set to:" + this.tam);
		
	}

	public String setJugador() {
		nombreJugador = JOptionPane.showInputDialog(null, "Ingresar el nombre del jugador");
		panelInfo.actualizarNombre(nombreJugador);
		return nombreJugador;

	}

	public void setDificultad(int dificultad){
		this.dificultad = dificultad;
		System.out.println("Dificultad set to:"  + this.dificultad);
	}

	public boolean[][] darTableroModelo(){
		
		boolean [][] tab = modelo.darTablero();
		
		for(int i = 0; i < tab.length; i++) {
			for(int j = 0; j < tab[i].length; j++) {
				System.out.print(tab[i][j] + "  ");
			}
			System.out.println();
		}
		System.out.println();
		
		return modelo.darTablero();
	}
	
	public void openTop10() {
		Collection<RegistroTop10> registros = top10.darRegistros();
		VentanaTop10 top10 = new VentanaTop10(registros); 
		
		top10.setLocationRelativeTo(this);
		top10.pack(); 
		top10.setModal(true); 
		top10.setVisible(true);
	}

	

	public static void main(String[] args) {
		
		FlatDarkLaf.install(); 
		new VentanaLightsOut(); 
	}
	

}
