package uniandes.dpoo.taller4.interfaz;

import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

import uniandes.dpoo.taller4.modelo.Tablero;

import java.awt.*;

@SuppressWarnings("serial")
public class PanelTablero extends JPanel implements MouseListener
{
	
	private VentanaLightsOut lights;
	
	private static final int TAM_ESPACIO_ENTRE_LUCES = 3;
	
	private boolean[][] luces;

    private int tam; 
    
    private static final int TAM_TABLERO = 300;
    
    private int[][] cantidades;
	
	public PanelTablero(VentanaLightsOut lights, int tam)
	{
		this.lights = lights;
        this.tam = tam; 
		this.cantidades = new int[tam][tam];
        addMouseListener(this);
        repaint();
		this.setLayout(null);
		this.setPreferredSize(new Dimension(300,300));
		this.setOpaque(true);
		this.setVisible(true);
		
		System.out.println("@Panel - tam: " + tam);
	}
	
	public void reiniciarCantidades() 
	{
		this.cantidades = new int[tam][tam];
	}

	public void actualizarTamano(int tamanio) 
	{
		this.tam = tamanio;
	}
	
	public void paint(Graphics g) 
	{
		Graphics2D g2d = (Graphics2D) g;
		g2d.setPaint(Color.BLACK);
		g2d.fillRect(0,0, TAM_TABLERO, TAM_TABLERO);
		luces = lights.darTableroModelo();
		
		int espacios = tam+1;
		int ancho = (TAM_TABLERO-espacios*TAM_ESPACIO_ENTRE_LUCES)/tam;
		int corx = TAM_ESPACIO_ENTRE_LUCES;
		int cory = TAM_ESPACIO_ENTRE_LUCES;
		
		System.out.println("@Panel.paint - tam " + tam + this.hashCode());
		GradientPaint yellWhite = new GradientPaint(0, 0, Color.WHITE, ancho, ancho, Color.YELLOW);
		GradientPaint grayDark = new GradientPaint(0, 0, Color.BLACK, ancho, ancho, Color.GRAY);
		for (int i = 0; i < tam; i++)
		{
			for (int j = 0; j < tam; j++)
			{			
				if(luces[i][j]==true) {
					yellWhite = new GradientPaint(corx, cory, Color.WHITE, corx+ancho, cory+ancho, Color.YELLOW);
					g2d.setPaint(yellWhite);
					g2d.fillRoundRect(corx,cory, ancho,ancho,25,25);	
					if(cantidades[i][j]!=0)
					{
						g2d.setPaint(Color.black);
						g2d.drawString(Integer.toString(cantidades[i][j]), corx+ancho/2, cory+ancho/2);
					}			
					
				}
				else {
					grayDark = new GradientPaint(corx, cory, Color.BLACK, corx+ ancho, cory+ancho, Color.GRAY);
					g2d.setPaint(grayDark);
					g2d.fillRoundRect(corx,cory, ancho,ancho,25,25);	
					if(cantidades[i][j]!=0)
					{
						g2d.setPaint(Color.white);
						g2d.drawString(Integer.toString(cantidades[i][j]), corx+ancho/2, cory+ancho/2);
					}
				}
				corx += ancho + TAM_ESPACIO_ENTRE_LUCES;
			}
			corx=TAM_ESPACIO_ENTRE_LUCES;
			cory += ancho + TAM_ESPACIO_ENTRE_LUCES;
		}
	} 
	
	public void mouseClicked(MouseEvent e) 
	{
        int click_x = e.getX();
        int click_y = e.getY();
        int[] casilla = convertirCoordenadasACasilla(click_x, click_y);
        try {
			lights.jugar(casilla[0], casilla[1]);
			cantidades[casilla[0]][casilla[1]]++;
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        //this.ultima_fila = casilla[0];
        //this.ultima_columna = casilla[1];
        repaint();
    }
	
    private int[] convertirCoordenadasACasilla(int x, int y)
    {
    	int ladoTablero = tam;
    	int altoPanelTablero = getHeight();
    	int anchoPanelTablero = getWidth();
    	int altoCasilla = altoPanelTablero / ladoTablero;
    	int anchoCasilla = anchoPanelTablero / ladoTablero;
    	int fila = (int) (y / altoCasilla);
    	int columna = (int) (x / anchoCasilla);
    	return new int[] { fila, columna };
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	/*
	public void mouseDragged(MouseEvent e) {
		int mcorx = e.getX();
		int mcory = e.getY();

		int x = this.getX();
		int y = this.getY();
		int height = this.getHeight();
		int width = this.getWidth();

		int ancho = (TAM_TABLERO - (tam + 1)  * TAM_ESPACIO_ENTRE_LUCES) / tam;

		int[][][] ghost = new int[tam][tam][4];
		for (int i = 0; i < tam; ++i) {
			for (int j = 0; j < tam; ++j) {
				ghost[i][j][0] = x + ancho * j;
				ghost[i][j][1] = x + ancho * j;
			}
		}
	}
	*/

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}
